﻿using CHMPham.Logic;

using CHMPham.Models;
using Microsoft.AspNetCore.Mvc;
namespace CHMPham.ViewComponents
{
    public class GioHangViewComponent : ViewComponent
    {
        private readonly CHMPhamDbContext _context;
        public GioHangViewComponent(CHMPhamDbContext context)
        {
            _context = context;
        }
        public IViewComponentResult Invoke()
        {
            GioHangLogic gioHangLogic = new GioHangLogic(_context);
            decimal tongTien = gioHangLogic.LayTongTienSanPham();
            decimal tongSoLuong = gioHangLogic.LayTongSoLuong();
            TempData["TopMenu_TongTien"] = tongTien;
            TempData["TopMenu_TongSoLuong"] = tongSoLuong;
            return View("Default");
        }
    }
}