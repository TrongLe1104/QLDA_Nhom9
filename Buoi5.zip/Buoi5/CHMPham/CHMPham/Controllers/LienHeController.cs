﻿using Microsoft.AspNetCore.Mvc;
namespace CHMPham.Controllers
{
    public class LienHeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}