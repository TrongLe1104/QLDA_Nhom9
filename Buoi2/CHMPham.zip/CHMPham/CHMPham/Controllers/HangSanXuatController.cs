﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CHMPham.Models;
namespace CHMPham.Controllers
{
    public class HangSanXuatController : Controller
    {
        private readonly CHMPhamDbContext _context;
        public HangSanXuatController(CHMPhamDbContext context)
        {
            _context = context;
        }
        // GET: HangSanXuat
        public async Task<IActionResult> Index()
        {
            return _context.HangSanXuat != null ?
            View(await _context.HangSanXuat.ToListAsync()) :
            Problem("Entity set 'CHMPhamDbContext.HangSanXuat' is null.");
        }
// GET: HangSanXuat/Create
public IActionResult Create()
        {
            return View();
        }
        // POST: HangSanXuat/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,TenHangSanXuat")] HangSanXuat hangSanXuat)
        {
            if (ModelState.IsValid)
            {
                _context.Add(hangSanXuat);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(hangSanXuat);
        }
        // GET: HangSanXuat/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.HangSanXuat == null)
            {
                return NotFound();
            }
            var hangSanXuat = await _context.HangSanXuat.FindAsync(id);
            if (hangSanXuat == null)
            {
                return NotFound();
            }
            return View(hangSanXuat);
        }
        // POST: HangSanXuat/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,TenHangSanXuat")] HangSanXuat hangSanXuat)
        {
            if (id != hangSanXuat.ID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
{
                try
                {

                    _context.Update(hangSanXuat);
                    await _context.SaveChangesAsync();
                }

                catch (DbUpdateConcurrencyException)

                {

                    if (!HangSanXuatExists(hangSanXuat.ID))
                    {
                        return NotFound();

                    }
                    else
                    {
                        throw
                        ;

                    }
                }

                return RedirectToAction(nameof(Index));

            }

            return View(hangSanXuat);
        }
        // GET: HangSanXuat/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.HangSanXuat == null
            )

            {

                return NotFound();

            }

            var hangSanXuat = await _context.HangSanXuat
            .FirstOrDefaultAsync(m => m.ID == id);
            if (hangSanXuat == null
            )

            {

                return NotFound();

            }

            return View(hangSanXuat);
        }
        // POST: HangSanXuat/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.HangSanXuat == null
            )

            {

                return Problem("Entity set 'CHMPhamDbContext.HangSanXuat' is null.");
            
}
            var hangSanXuat = await _context.HangSanXuat.FindAsync(id);
            if (hangSanXuat != null)
            {
                _context.HangSanXuat.Remove(hangSanXuat);
            }
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        private bool HangSanXuatExists(int id)
        {
            return (_context.HangSanXuat?.Any(e => e.ID == id)).GetValueOrDefault();
        }
    }
}